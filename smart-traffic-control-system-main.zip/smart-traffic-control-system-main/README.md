An AI based smart traffic light control system based on traffic density and emergency vehicle detection.

